# Frontend Mentor - Social links profile solution

This is a solution to the [Social links profile challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/social-links-profile-UG32l9m6dQ). Frontend Mentor challenges help you improve your coding skills by building realistic projects. 

## Table of contents

- [Overview](#overview)
  - [The challenge](#the-challenge)
  - [Screenshot](#screenshot)
  - [Links](#links)
- [My process](#my-process)
  - [Built with](#built-with)
  - [What I learned](#what-i-learned)
  - [Continued development](#continued-development)
  - [Useful resources](#useful-resources)
- [Author](#author)


## Overview

### The challenge

Users should be able to:

- See hover and focus states for all interactive elements on the page

### Screenshot

[Active State](./design/active-states.png)
[Desktop-Preview](./design/desktop-preview.png)
[Mobile-Design](./design/mobile-design.png)


### Links

- Solution URL: [Add solution URL here](https://your-solution-url.com)
- Live Site URL: [Add live site URL here](https://your-live-site-url.com)

## My process

I examined the image supplied by Frontend Mentor and applied my discernment in crafting the design for this social media link profile.

### Built with

- Semantic HTML5 markup
- CSS custom properties
- Flexbox

### What I learned

Use this section to recap over some of your major learnings while working through this project. Writing these out and providing code samples of areas you want to highlight is a great way to reinforce your own knowledge.

To see how you can add code snippets, see below:

```html
<h1>Some HTML code I'm proud of</h1>
```
```css
.proud-of-this-css {
  color: papayawhip;
}
```
```js
const proudOfThisFunc = () => {
  console.log('🎉')
}
```


### Continued development

I'm currently utilizing Codecademy to support my coding journey. My notes proved valuable when I encountered difficulties in positioning specific elements within the design.


### Useful resources

- [W3 schools](https://www.w3schools.com/css/css_positioning.asp) - This assisted me in handling positions. I faced some challenges when arranging elements on the page, but referring to articles from W3 Schools has been greatly beneficial.


## Author

- LinkdIn - [La'Brea Rashad](https://www.linkedin.com/in/labrearashad)
- Frontend Mentor - [@TechBeauty](https://www.frontendmentor.io/profile/TechBeauty)

